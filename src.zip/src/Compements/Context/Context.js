import React from 'react';
const Mycontext = React.createContext();

export const Provider = Mycontext.Provider;
export const Consumer = Mycontext.Consumer;
